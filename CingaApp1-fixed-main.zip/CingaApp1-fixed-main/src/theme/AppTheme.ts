export const AppTheme = {
  // Colors
  colors: {
    primary: '#4361EE',     // Main brand color
    secondary: '#3A0CA3',   // Dark blue
    accent: '#4CC9F0',      // Light blue
    success: '#4CAF50',     // Green
    warning: '#FF9800',     // Orange
    error: '#F72585',       // Pink/Red
    background: '#F8F9FA',  // Light background
    surface: '#FFFFFF',     // Cards/surfaces
    text: {
      primary: '#212529',   // Dark text
      secondary: '#6C757D', // Gray text
      light: '#FFFFFF',     // White text
    },
    border: '#DEE2E6',      // Borders
  },

  // Typography
  typography: {
    headlineLarge: {
      fontSize: 32,
      fontWeight: 'bold',
      lineHeight: 40,
    },
    headlineMedium: {
      fontSize: 28,
      fontWeight: 'bold', 
      lineHeight: 36,
    },
    titleLarge: {
      fontSize: 22,
      fontWeight: 'bold',
      lineHeight: 28,
    },
    titleMedium: {
      fontSize: 18,
      fontWeight: '600',
      lineHeight: 24,
    },
    bodyLarge: {
      fontSize: 16,
      fontWeight: 'normal',
      lineHeight: 24,
    },
    bodyMedium: {
      fontSize: 14,
      fontWeight: 'normal',
      lineHeight: 20,
    },
    bodySmall: {
      fontSize: 12,
      fontWeight: 'normal',
      lineHeight: 16,
    },
  },

  // Spacing
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },

  // Border Radius
  borderRadius: {
    sm: 8,
    md: 12,
    lg: 16,
    xl: 24,
  },

  // Shadows
  shadows: {
    sm: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.1,
      shadowRadius: 2,
      elevation: 2,
    },
    md: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.15,
      shadowRadius: 4,
      elevation: 4,
    },
    lg: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.2,
      shadowRadius: 8,
      elevation: 8,
    },
  },
};