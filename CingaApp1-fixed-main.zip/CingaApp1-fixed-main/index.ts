﻿// Remove this line if you don't need dev client
// import 'expo-dev-client';

import { registerRootComponent } from 'expo';
import App from './App';

registerRootComponent(App);